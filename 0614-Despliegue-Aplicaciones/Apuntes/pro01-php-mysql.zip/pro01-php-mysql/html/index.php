<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Acceso a base de datos</title>
</head>
<body>
	<?php
	// Parámetros para la conexión a la base de datos
	// En $host no indicamos "localhost", 
	// en Docker debes usar el nombre del servicio que pusiste en el archivo YAML
	// (en nuestro caso, $host = 'base-de-datos';)
	$host = 'base-de-datos';
	$user = 'root';
	$pass = 'root';
	// Cadena de conexión
	$conn = new mysqli($host, $user, $pass);
	// Conexión a la base de datos
	if($conn->connect_error){
		 echo "Error en la conexión a la base de datos";
	}
	else{
		echo "Conexión exitosa a la base de datos";
	}
	?>
</body>
</html>