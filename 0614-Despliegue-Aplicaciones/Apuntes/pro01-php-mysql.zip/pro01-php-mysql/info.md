Docker - Servidor de Apache con PHP y MySQL
Borja Alcaraz

---------------------------------------------------------------------------------
Paso 1. Inciar Docker
---------------------------------------------------------------------------------

Iniciar la aplicación de Docker.


---------------------------------------------------------------------------------
Paso 2. Estructura de los ficheros del proyecto
---------------------------------------------------------------------------------

En la ruta:

Windows
C:\Users\balcaraz\Documents\phpMySQLProjects

macOS
Macintosh HD/Usuarios/borjaalcaraz/phpMySQLProjects

Estructura:

pro01-php-mysql/
├── html/
│   └── index.php
├── docker-compose.yml
└── info.md


---------------------------------------------------------------------------------
Paso 3. Descargar las imágenes y montar el contenedor “pro01-php-mysql”
---------------------------------------------------------------------------------

Desde la terminal (Windows):
cd C:\Users\balcaraz\Documents\phpMySQLProjects\pro01-php-mysql
docker-compose up -d


---------------------------------------------------------------------------------
Paso 4. Acceder al contenido desde el navegador
---------------------------------------------------------------------------------

http://localhost


---------------------------------------------------------------------------------
Paso 5. Acceder phpMyAdmin desde el navegador (usuario: root, contraseña: root)
---------------------------------------------------------------------------------

http://localhost:8081/


---------------------------------------------------------------------------------
Paso 6. Acceder a la base de datos desde la terminal
---------------------------------------------------------------------------------

docker exec -it mi-mysql mysql -u root -p
use bd1


---------------------------------------------------------------------------------
Paso 7. Instrucciones generales de uso
---------------------------------------------------------------------------------

Detenerlo sin borrar nada
docker-compose stop

Volver a arrancarlo
docker-compose start

Apagarlo y borrar los contenedores (limpieza)
docker-compose down

Ver si está corriendo
docker ps


---------------------------------------------------------------------------------
Paso 8. Resumen de puertos
---------------------------------------------------------------------------------

80		    Tu web (Apache/PHP)
8081		phpMyAdmin
3306		Conexión directa a la base de datos desde fuera