console.log("Hola Mundo")
console.log('HOla MUndo') //alt 39 = '
console.log(`HOLA MUNDO`) //alt 96 = `

// alt 92 = \

/*
esto es 
un comentario 
de varias 
lineas
*/

