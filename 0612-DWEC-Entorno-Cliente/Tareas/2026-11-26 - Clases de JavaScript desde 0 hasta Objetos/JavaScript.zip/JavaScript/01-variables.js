// variables

// var 

var nombre = "Jorge"
console.log(nombre)
// let

let nombre2 = "JOrge"
console.log(nombre2)
nombre2 = "Eduardo"
console.log(nombre2)

// const

const apellido = "Moya"
console.log(apellido)
