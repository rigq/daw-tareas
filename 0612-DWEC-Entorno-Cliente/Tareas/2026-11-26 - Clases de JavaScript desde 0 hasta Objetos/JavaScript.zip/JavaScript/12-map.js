// MAPAS

// Declaración
let myMap = new Map()
console.log(myMap)

// Inicializar

myMap = new Map([
    ["name", "Jorge"],
    ["email", "Jeduardo@digitechfp.com"],
    ["age", 47]
])

console.log(myMap)

// Métodos Comunes

// set
myMap.set("alias", "YOMISMO")
myMap.set("name", "Eduardo")
myMap.set("segNombre", "Eduardo")

console.log(myMap)

// get

console.log(myMap.get("name"))
console.log(myMap.get("email"))

// has 
console.log(myMap.has("age"))

// Delete
myMap.delete("email")
console.log(myMap)

// keys, values y entries

console.log(myMap.keys())
console.log(myMap.values())
console.log(myMap.entries())

// size
console.log(myMap.size)

// Clear
myMap.clear()
console.log(myMap)

