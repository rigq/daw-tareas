// SETs

// Declaración

let mySet = new Set()
console.log(mySet)

// Métodos Comunes 

// add y Delete
mySet.add("www.js/inicio")
console.log(mySet)

mySet.delete("www.js/inicio")
console.log(mySet)

// HAS

console.log(mySet.has("Jorge"))

//size
mySet = new Set(["Jorge", "Moya", "JORGEMOYA", 47])
console.log(mySet.size)

// Convertir un Set en un arreglo

let myArray = Array.from(mySet)
console.log(myArray)

// Convertir un ARRAY en un SET

mySet = new Set(myArray)
console.log(mySet)

