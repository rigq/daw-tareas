
// Cadena de texto (String)
let name = "Jorge"
let alias = "JorgeMoya"
let email = "jeduardo.moya@digitechfp.com"

// numéricos

let age = 48
let altura = 1.72

// Booleanos (Boolean)
let isTeacher = true
let isStudient = false

// Indefinido (Undefined)

let undefinedValue


// nulo (null)
let nullValue = null

// BigInt
let myBigInt = BigInt(65165165165156165165156156165156153184546848468486186468)
let myBigInt2 =  56911651561651651561615151516156156165165161n


console.log(name)
console.log(alias)
console.log(email)
console.log(age)
console.log(altura)
console.log(isTeacher)
console.log(isStudient)
console.log(undefinedValue)
console.log(nullValue)
console.log(myBigInt)
console.log(myBigInt2)
