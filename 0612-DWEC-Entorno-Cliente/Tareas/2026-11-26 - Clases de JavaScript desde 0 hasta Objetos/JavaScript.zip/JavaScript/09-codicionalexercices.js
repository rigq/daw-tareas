/*
1.- Imprime por consola tu nombre si una variable toma su valor
2.- Imprime por consola un mensaje si el usuario y 
contraseña coinciden con los establecidos
3.- Verifica si un número es positivo, negativo o cero 
e imprime un mensaje con el resultado
4.- Verifica si una persona puede votar o no (Mayor o igual a 18) 
e indica cuantos años le faltan
5.- Usa el operador ternario para asignar el valor "adulto" o "menor 
a una variable dependiendo de la edad"
6.- Muestra en que estación del año nos encontramos dependiendo del mes 
de una variable (usa IF)
*//*
7.- muestra el número de días que tiene un mes deendiendo de la 
variable del ejercicio anterior (usa IF)
8.- Usa un switch para imprimir un messaje de saludo diferente 
dependiendo del idioma.
9.- Usa un Switch para realizar el ejercicio 6.
10.- Usa un Switch para realizar el ejercicio 7.*/