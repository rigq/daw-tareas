// Operadores Aritméticos

let a = 5
let b = 10

console.log(a + b)
console.log(a - b)
console.log(a * b)
console.log(a / b)
console.log(a % b) // módulo de una división
console.log(a ** b) // número elevado como potencia

// Operador de Incremento
a++

// Operador de Decremento
b--

// Operadores de Asignación

let myVariable = 2
myVariable += 5
myVariable -= 5
myVariable /= 5
myVariable %= 5
myVariable **= 5

// Operadores de Comparación
a = 6
console.log(a > b)
console.log(a < b)
console.log(a >= b)
console.log(a <= b)
console.log(a == b)
console.log(a == 6)
console.log(a == "6")
console.log(a == a)
console.log(a === "6")
console.log(a != 6)
console.log(a !== 6)
console.log(0 == false)
console.log(1 == false)
console.log(0 == "")
console.log(0 == " ")
console.log('')
console.log(undefined == null)
console.log(undefined === null)

// Operadores Lógicos

  //and (&&)
console.log(5 > 10 && 15 > 20)
console.log(5 < 10 && 15 > 20)

  //or (||)
console.log(5 > 10 || 15 > 20 )
console.log(5 < 10 || 15 > 20 )

  // Operadores ternarios
const isRaining = false
isRaining ? console.log("Está lloviendo") : console.log("No està lloviendo")