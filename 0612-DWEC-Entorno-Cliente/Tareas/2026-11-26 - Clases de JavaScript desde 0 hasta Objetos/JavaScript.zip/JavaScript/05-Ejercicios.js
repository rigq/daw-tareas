// Ejercicios en Clase
/*
Imprime 5 comparaciones falsas con diferentes operadores de comparación
Imprime 5 comparaciones verdaderas con diferentes operadores de comparación
Imprime una variable que contenga el resultado de un operador lógico and
Imprime una variable que contenga el resultado de un operador aritmético
Utiliza el operador ternario para comparar
*/

/* Ejercicios  08/10/2026 */

/*
1.- Realiza un programa que permita calcular el 
área de una circunferencia con un radio dado.

2.- Realiza un programa que permita calcular un promedio de 5 números y 
que indique cuál es el mayor entre ellos.

3.- Realiza un programa que permita calcular la transformación de unidades
100 metros a cm cuadrados.

4.- realiza un programa que permita calcular el áerea de un cubo inscrito 
en una circunferencia.

*/
