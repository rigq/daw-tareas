// Objetos

// Sintáxis

let person = {
    name: "Jorge",
    age: 47,
    alias: "JORGEMOYA"
}

// Acceso a propiedades

// Notación Punto
console.log(person.name)

// Notación de Corchetes
console.log(person["name"])

// Modificación de Propiedades

person.name = "Jorge Moya"
console.log(person.name)


console.log(typeof person.age)
person.age = "47"
console.log(typeof person.age)

// Eliminación de Propiedades

delete person.age
console.log(person)

// Nueva Propiedad

person.email = "Jmoya@digitechfp.com"
person["age"] = 47

console.log(person)

// Métodos (funciones)

let person2 = {
    name: "Jorge",
    age: 47,
    alias: "JORGEMOYA",
    walk: function(){
        console.log("La persona camina")
    }
}
person2.walk()

// Anidación de Objetos

let person3 = {
    name: "Jorge",
    age: 47,
    alias: "JORGEMOYA",
    walk: function(){
        console.log("La persona camina")
    },
    job: {
        name: "Programar",
        exp: 23,
        work: function(){
            console.log(`La persona de ${person3.age} años,  trabaja `)
        }
    }
}

console.log(person3)
console.log(person3.name)
console.log(person3.job)
console.log(person3.job.name)
person3.job.work()

// Igualdad de Objetos

let person4 = {
    name: "Jorge",
    age: 47,
    alias: "JORGEMOYA"
}
let person5 = {
    name: "Jorge",
    age: 47,
    alias: "JORGEMOYA"
}

console.log(person5)
console.log(person4)

console.log(person4 == person5)
console.log(person4 === person5)

console.log(person4.name == person5.name)