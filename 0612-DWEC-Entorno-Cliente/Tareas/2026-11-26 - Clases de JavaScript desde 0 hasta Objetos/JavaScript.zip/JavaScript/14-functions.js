function myFunc(){
    console.log("Hola JavaScript")
}

for (let i = 0; i < 5 ; i++){
    myFunc()
}

// Función con parámetros

function myFuncWithParams (name){
    console.log(`Hola, ${name}`)
}

myFuncWithParams("Jorge")
myFuncWithParams("Moya")

// Funciones anónimas

const myFunc2 = function (name){
     console.log(`Hola, ${name}`)
}

myFunc2("Jorge Moya")

// Función Arrow

const myFunc3 = (name) => {
         console.log(`Hola, ${name}`)
}

const myFunc4 = (name) => console.log(`Hola, ${name}`)

myFunc3("Eduardo Alvarez")
myFunc4("Elias Nieto")

// Parámetros

function sum(a, b){
    console.log(a + b)
}

sum(5, 10)
sum(5)
sum()

// Función por Defecto

function defaultSum(a = 0, b = 0){
        console.log(a + b)
}

defaultSum()
defaultSum(5)
defaultSum(5, 10)
defaultSum(undefined, 5)

// Retorno de Valores

function mult(a, b){
    return a * b
}

let result = mult(5,10)
console.log(result)
console.log(mult(5, 10))

// Funciones anidadas 
function extern(){
    console.log("Esta es una función externa")
    function intern(){
        console.log("Esta es una función interna")
    }
    intern()
}
extern()

// Función de Orden Superior

function applyFunc(func, param){
    func(param)
}
applyFunc(myFunc4, "función de orden Superior")


// forEach

myArray = [1, 2, 3, 4]

mySet = new Set(["Jorge", "Moya", "JORGEMOYA", 47])

myMap = new Map([
    ["name", "Jorge"],
    ["email", "Jeduardo@digitechfp.com"],
    ["age", 47]
])

myArray.forEach(function (value) {
    console.log(value)
})

myArray.forEach((value) => console.log(value))

mySet.forEach((value) => console.log(value))

myMap.forEach((value) => console.log(value))
