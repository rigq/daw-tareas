// LOOPS O BUCLES

// for
for (let i = 1; i < 6; i++){
    console.log(`Hola ${i}`)
}

const numbers = [1, 2, 3, 44, 5, 6, 7, 8, 9, 10, 12, 14]

for (let i = 0; i < numbers.length; i++){
    console.log(`Elemento: ${numbers[i]}`)
}

// while
let i = 1
while (i <= 5){
    console.log(`Hola ${i}`)
    i++
}

// do while

i = 6
do{
    console.log(`Hola ${i}`)
    i++
} while (i < 5)

// for of

const myArray = [1, 2, 3, 4]

const mySet = new Set(["Jorge", "Moya", "JORGEMOYA", 47])

const myMap = new Map([
    ["name", "Jorge"],
    ["email", "Jeduardo@digitechfp.com"],
    ["age", 47]
])

const myString = "Hola JavaScript"

for (value of myArray){
    console.log(value)
}

for (value of mySet){
    console.log(value)
}

for (value of myMap){
    console.log(value)
}

for (value of myString){
    console.log(value)
}

// break y continue

for (let i = 0; i < 10; i++){
    if (i == 5){
        continue
    } else if (i == 7){
        break
    }
    console.log(`Hola ${i}`)
}


