/*  08/10/2026

1.- concatena dos cadenas de Texto
2.- Muestra la longitud de una cadena de texto
3.- muestra el primer y último caracter de un string
4.- convierte a mayúsculas y minúsculas un texto
5.- crea una cadena de texto en varias líneas
6.- Interpola el valor de una variable en un String
7.- Reemplaza todos los espacios en blanco de un string por guiones
8.- comprueba si una cadena de texto contiene una palabra concreta
9.- Comprueba si dos Strings son Iguales
10.- Comprueba si dos Strings tienen la misma longitud
*/
