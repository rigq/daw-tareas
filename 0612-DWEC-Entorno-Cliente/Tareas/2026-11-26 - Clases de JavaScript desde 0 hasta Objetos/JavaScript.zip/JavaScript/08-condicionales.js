// if, else if, else

let age = 10

if (age == 47){
    console.log("La edad es 47")
}
else if (age >= 18){
    console.log("Es mayor de edad")
}
else if (age <=18){
    console.log("Es menor de edad")
}
else {
    console.log("La edad no es 47")
}

/* Operadores ternarios */

const message = age >= 18 ? "La mayor de edad" : "Es menor de Edad"
console.log(message)

// switch

let day = 3
let dayName 

switch (day){
    case 1:
        dayName = "Lunes"
        break
    case 2:
        dayName = "Martes"
        break
    case 3:
        dayName = "Miércoles"
        break
    case 4:
        dayName = "Jueves"
        break
    case 5:
        dayName = "Viernes"
        break
    case 6:
        dayName = "Sábado"
        break
    case 7:
        dayName = "Domingo"
        break
}

console.log(dayName)