// Cadena de Caracteres (Strings)

// Concatenación

let myName = "Jorge"
let greeting = "Hola " + myName + "!"
console.log(greeting)
console.log(typeof greeting)

// longitud de cadenas de texto

console.log(greeting.length)

// Acceso a caracteres

console.log(greeting[0])
console.log(greeting[11])

// Métodos
console.log(greeting.toUpperCase()) //Mayúsculas
console.log(greeting.toLowerCase()) // Minúsculas
console.log(greeting.indexOf("Hola")) // Índice
console.log(greeting.includes("Hola"))
console.log(greeting.slice(1,3))

// Strings en varias líneas

let message = `Hola, este 
es un 
mensaje en varias
lineas de JavaScript`

console.log(message)

// interpolación de valores
let email = "jeduardo.moya@digitechfp.com"
console.log("Hola, ${myName}! Tu email es ${email}")